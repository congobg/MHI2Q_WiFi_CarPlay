#!/bin/sh
# RGI-H 7: keeps exactly one maneuver_render (maneuver_render_H) alive.
#   /bin/sh /mnt/app/eso/hmi/lib/rgi/rgi_render_sup.sh [first-start delay s] &
# Singleton (a second copy exits).  The renderer is a TCP client of the Java
# RendererServer on 127.0.0.1:19800 and draws displayable 98 (created by xTcpLogH from
# /mnt/app/eso/hmi/lib/rgd_blank.png at HMI start).  It is never killed by us; stop with
# an empty /mnt/ota/app/rgd_disable (the running renderer is left alone), or
# /tmp/rgd_disable until the next reboot - also written by the AltScreen.sh crash
# watch when maneuver_render crashes twice within 10 min (no endless restarts).
BIN=/mnt/app/eso/hmi/lib/rgi/maneuver_render
LOG=/dev/shmem/maneuver_render.log
SLOG=/dev/shmem/rgi_render_sup.log
LOCK=/dev/shmem/rgi_render_sup.pid
RPID=/dev/shmem/rgi_maneuver_render.pid
FIRST_DELAY=60
case "$1" in [0-9]*) FIRST_DELAY=$1 ;; esac

slog() { echo "`date` $*" >> "$SLOG" 2>/dev/null; }
alive() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }
off() { [ -f /mnt/ota/app/rgd_disable ] || [ -f /tmp/rgd_disable ]; }
cap_log() {
    [ -f "$1" ] || return 0
    set -- "$1" `ls -l "$1" 2>/dev/null`
    [ -n "$6" ] && [ "$6" -gt 524288 ] 2>/dev/null && mv -f "$1" "$1.1"
}

off && exit 0
if [ -f "$LOCK" ]; then
    read old < "$LOCK"
    alive "$old" && exit 0
fi
echo $$ > "$LOCK"

unset LD_PRELOAD
# Full HMI library path (libdisplayinit in /eso/lib).  It matters for more than the window:
# with /mnt/app/armle/lib/dll etc. on the path the NVIDIA driver reported
# GL_SHADER_COMPILER=1 and accepted the blobs (compile status 1); with the short path it
# reported 0 / status 0 (car 2026-10-14).
LD_LIBRARY_PATH=/mnt/app/root/lib-target:/eso/lib:/mnt/app/usr/lib:/mnt/app/armle/lib:/mnt/app/armle/lib/dll:/mnt/app/armle/usr/lib:/usr/lib:/lib:/proc/boot
export LD_LIBRARY_PATH
[ -x "$BIN" ] || chmod 755 "$BIN" 2>/dev/null
cd /mnt/app/eso/hmi/lib || exit 1          # ./shaders/*.bin and ./flag_atlas.rgba

pid=
[ -f "$RPID" ] && read pid < "$RPID"
alive "$pid" && slog "adopting running maneuver_render pid=$pid" || pid=
slog "supervisor pid=$$ start (first delay ${FIRST_DELAY} s)"
if [ -z "$pid" ] && [ "$FIRST_DELAY" -gt 0 ]; then
    i=0
    while [ "$i" -lt "$FIRST_DELAY" ] && ! off; do sleep 1; i=$((i+1)); done
fi
ticks=0
while ! off; do
    if ! alive "$pid"; then
        if [ "$ticks" -gt 0 ]; then
            slog "maneuver_render pid=$pid gone - restart in 5 s"
            sleep 5
        fi
        "$BIN" </dev/null >> "$LOG" 2>&1 &
        pid=$!
        echo "$pid" > "$RPID"
        slog "started maneuver_render pid=$pid"
    fi
    # every 10 s (was 2 s: one "sleep" process every 2 s for the whole drive);
    # a crashed renderer is back within 10 + 5 s
    sleep 10
    ticks=$((ticks+1))
    if [ $((ticks % 30)) -eq 0 ]; then cap_log "$LOG"; cap_log "$SLOG"; fi
done
slog "rgd_disable - supervisor ends (renderer pid=$pid left running)"
rm -f "$LOCK"
