#!/bin/sh
# start-ap.sh  - RGI-Q overlay for /eso/telephone/start-ap.sh
#
# Stock behaviour, plus: HT20 instead of HT40, a chosen channel, and a WPA2
# passphrase instead of a raw 64-hex key (wireless Android Auto).
#
# called by connectionmanager:  start-ap.sh <0|1 = listen-before-talk> <cfg file>
# called by hand / by RGI-Q:    start-ap.sh reapply [cfg file]
#     re-applies the config to an AP that is already running
#     (e.g. one the stock script brought up before the overlay was mounted)
# called by wcp-boot.sh:         start-ap.sh ie
#     installs the Apple element again (the car's Bluetooth address is known)

UAP=/mnt/app/armle/sbin/uaputl
LOG=/tmp/start-ap.log
WCP_CFG=/tmp/uaputl_wcp.cfg

WCP_HTCAP=0x012c   # HT20 + short GI 20, RX STBC   (stock 0x116e = HT40)
# Apple vendor element for wireless CarPlay (luka-dev format): flags 80 22
# (AirPlay, wireless CarPlay, 2.4 GHz), then this car's Bluetooth MAC and the
# device ID (= the access point's MAC). Built at run time, so it fits every car
# (3638 and 5092 alike; the fixed element used until 27.10 carried a wrong
# Bluetooth MAC, ...64:CF instead of ...64:0F):
#   Bluetooth MAC: BTMAC in /mnt/ota/app/wcp.conf, else /tmp/wcp_btmac (libbthook,
#                  ~10 s after boot, i.e. after the first AP start), else
#                  /mnt/ota/wcp/btmac.last (saved by wcp-boot.sh at the last boot)
#   AP MAC:        uaputl sys_cfg_ap_mac_address, else ifconfig uap0
# WCP_APPLE_IE in /mnt/ota/app/wcp.conf: a fixed element (0xdd18...) or "off".
WCP_APPLE_IE=
[ -f /mnt/ota/app/wcp.conf ] && . /mnt/ota/app/wcp.conf
WCP_IE_INDEX=3
WCP_CHANNEL=${WCP_CHANNEL-6}   # 1 / 6 / 11 = fixed channel (default 6; wcp.conf may set it)
                   # 0          = auto channel select (ACS) at every AP start
                   # empty      = keep connectionmanager's channel, just drop HT40
# WPA2 key. connectionmanager gives this AP a raw 64-hex key. An iPhone takes that
# as it is, but Android Auto can only hand Android a passphrase (8-63 characters):
# phone log 29.10, "validatePassword failed: ASCII string size too large: 66", the
# phone then reports STATUS_WIFI_NETWORK_UNAVAILABLE. So the AP gets a passphrase;
# wcpd and aawd read the credentials from $WCP_CFG, so iPhone and Android phone
# get the same one. WCP_PASSPHRASE in /mnt/ota/app/wcp.conf:
#   empty (default)  the first 32 characters of connectionmanager's 64-hex key
#                    (follows that key; a passphrase from connectionmanager -
#                    e.g. one set for a passenger hotspot - is left as it is)
#   keep             connectionmanager's key unchanged (no wireless Android Auto)
#   <8-63 characters> this passphrase (letters, digits and . _ + = @ % , : - only)
WCP_PASSPHRASE=${WCP_PASSPHRASE-}

# ---------------------------------------------------------------------------
# No IPv6 on the access point. The CarPlay receiver accepts an IPv6 connection on uap0
# but answers the iPhone's pairing request with 404 (the same request over IPv4: 200).
# After USB the iPhone tries the IPv6 link-local address first and then waits for the
# next StartSession (25-55 s); without it, it connects over IPv4 at once (car 30.10,
# confirmed by hand). uap0 gets its link-local address when the connection manager
# brings it up, i.e. after this script: a background watcher removes any IPv6 address
# that appears within 60 s - but only once the access point broadcasts. Removing it
# while the connection manager was still bringing uap0 up held the access point back
# until the watcher ended (car 31.10, 5092: BSS start at 74 s instead of ~10 s; with
# wcp_keep_ipv6 the phone was on the Wi-Fi at 30 s). wcpd checks again before every
# offer. Off: /mnt/ota/app/wcp_keep_ipv6.
drop_ipv6_bg()
{
    [ -e /mnt/ota/app/wcp_keep_ipv6 ] && return 0
    (
        _I=0
        while [ $_I -lt 180 ] && ! bss_started; do
            sleep 1
            _I=$((_I+1))
        done
        if ! bss_started; then
            echo "IPv6: the access point did not start within 180 s - uap0 left alone" >> $LOG
            exit 0
        fi
        echo "access point broadcasting ($_I s after start-ap.sh) - IPv6 on uap0 removed from now on, for 60 s" >> $LOG
        _I=0
        while [ $_I -lt 60 ]; do
            for _A in `ifconfig uap0 2>/dev/null | sed -n 's/^[[:space:]]*inet6 \([^ ]*\).*/\1/p'`; do
                ifconfig uap0 inet6 "$_A" delete >> $LOG 2>&1 && \
                    echo "IPv6 address $_A on uap0 removed (receiver refuses pairing over IPv6)" >> $LOG
            done
            sleep 1
            _I=$((_I+1))
        done
    ) </dev/null >/dev/null 2>&1 &
}

bss_started()
{
    [[ `$UAP sys_cfg_bss_status` = "BSS status = started" ]]
}

make_cfg()   # $1 = stock config written by connectionmanager -> $WCP_CFG
{
    case "$WCP_CHANNEL" in
        "") _C1='s/^ *Channel=0,[0-9]*/ Channel=0,1/'
            _C2='s/^ *Channel=\([1-9][0-9]*\),[0-9]*/ Channel=\1,0/' ;;
        0)  _C1='s/^ *Channel=.*/ Channel=0,1/'
            _C2='s/^$//' ;;
        *)  _C1="s/^ *Channel=.*/ Channel=$WCP_CHANNEL,0/"
            _C2='s/^$//' ;;
    esac
    # PSK: see WCP_PASSPHRASE (only a 64-hex key is replaced, quoted or not)
    _H8='[0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F]'
    _H64="$_H8$_H8$_H8$_H8$_H8$_H8$_H8$_H8"
    case "$WCP_PASSPHRASE" in
        "")   _P1="s/^\\( *PSK=\"*\\)\\($_H8$_H8$_H8$_H8\\)$_H8$_H8$_H8$_H8\\(\"*\\) *\$/\\1\\2\\3/"
              _PW="the first 32 characters of the stock key" ;;
        keep) _P1='s/^$//'
              _PW="stock key kept (WCP_PASSPHRASE=keep)" ;;
        *)    if [ ${#WCP_PASSPHRASE} -lt 8 ] || [ ${#WCP_PASSPHRASE} -gt 63 ]; then
                  _P1='s/^$//'; _PW="WCP_PASSPHRASE ignored: ${#WCP_PASSPHRASE} characters (8-63) - stock key kept"
              else
                  case "$WCP_PASSPHRASE" in
                      *[!A-Za-z0-9._+=@%,:-]*)
                          _P1='s/^$//'; _PW="WCP_PASSPHRASE ignored: characters other than A-Z a-z 0-9 . _ + = @ % , : - - stock key kept" ;;
                      *)  _P1="s/^\\( *PSK=\"*\\)$_H64\\(\"*\\) *\$/\\1$WCP_PASSPHRASE\\2/"
                          _PW="WCP_PASSPHRASE from wcp.conf (${#WCP_PASSPHRASE} characters)" ;;
                  esac
              fi ;;
    esac
    sed -e "s/^ *HTCapInfo=.*/ HTCapInfo=$WCP_HTCAP/" -e "$_C1" -e "$_C2" -e "$_P1" "$1" > "$WCP_CFG"
    if grep "^ *PSK=\"*$_H64\"* *\$" "$WCP_CFG" > /dev/null 2>&1; then
        echo "key: raw 64-hex key ($_PW) - wireless Android Auto cannot use it" >> $LOG
    elif grep "^ *PSK=\"*$_H64\"* *\$" "$1" > /dev/null 2>&1; then
        echo "key: passphrase instead of the raw 64-hex key ($_PW)" >> $LOG
    fi
}

mac_hex()    # "2C:DC:AD:4C:64:0F" -> "2cdcad4c640f" (empty unless 6 bytes)
{
    # sed y instead of tr (MHI2 H has no tr - the Apple element was never built there)
    _M=`echo "$1" | sed -e 'y/ABCDEF/abcdef/' | sed -n 's/^ *\([0-9a-f][0-9a-f]\)[:-]\([0-9a-f][0-9a-f]\)[:-]\([0-9a-f][0-9a-f]\)[:-]\([0-9a-f][0-9a-f]\)[:-]\([0-9a-f][0-9a-f]\)[:-]\([0-9a-f][0-9a-f]\).*/\1\2\3\4\5\6/p'`
    [ "$_M" != "000000000000" ] && echo "$_M"
}

make_ie()    # -> $_IE (empty: not enough known)
{
    _IE=
    case "$WCP_APPLE_IE" in
        off) return 0 ;;
        0x*) _IE=$WCP_APPLE_IE; return 0 ;;
    esac
    _BT=`mac_hex "$BTMAC"`
    [ -z "$_BT" ] && [ -s /tmp/wcp_btmac ] && _BT=`mac_hex "$(cat /tmp/wcp_btmac)"`
    [ -z "$_BT" ] && [ -s /mnt/ota/wcp/btmac.last ] && _BT=`mac_hex "$(cat /mnt/ota/wcp/btmac.last)"`
    _AP=`$UAP sys_cfg_ap_mac_address 2>/dev/null | sed -n 's/.*= *//p'`
    _AP=`mac_hex "$_AP"`
    [ -z "$_AP" ] && _AP=`mac_hex "$(ifconfig uap0 2>/dev/null | sed -n 's/.*address: *//p')"`
    if [ -z "$_BT" ] || [ -z "$_AP" ]; then
        echo "Apple element: not installed (Bluetooth MAC '${_BT:-?}', AP MAC '${_AP:-?}')" >> $LOG
        return 0
    fi
    _IE=0xdd1800a04000000280220606${_BT}0706${_AP}
}

apply_ie()   # Apple vendor element in beacon / probe / (re)association responses
{
    make_ie
    [ -n "$_IE" ] || return 0
    $UAP sys_cfg_custom_ie $WCP_IE_INDEX 0x12a $_IE >> $LOG 2>&1
    echo "Apple element: $_IE" >> $LOG
}

apply_cfg()  # $1 = stock config; use the modified one, fall back to stock on any error
{
    if [ -s "$1" ] && make_cfg "$1" && [ -s "$WCP_CFG" ]; then
        _OUT=`$UAP sys_config "$WCP_CFG" 2>&1`
        _RC=$?
        echo "$_OUT" >> $LOG
        case "$_OUT" in *ERR*) _RC=1 ;; esac
        if [ $_RC -eq 0 ]; then
            echo "applied $WCP_CFG (HTCap $WCP_HTCAP, channel '${WCP_CHANNEL:-cm}')" >> $LOG
            return 0
        fi
        echo "modified config rejected - falling back to stock $1" >> $LOG
    fi
    rm -f "$WCP_CFG"         # the AP runs the stock config: wcpd/aawd read that one (its key)
    $UAP sys_config "$1" >> $LOG 2>&1
}

echo "=== `date 2>/dev/null` start-ap.sh $*" >> $LOG     # date: not on MHI2 H

# ---- Apple element again on the running AP (wcp-boot.sh, address now known) -
if [ "$1" = "ie" ]; then
    apply_ie
    exit 0
fi

# ---- reapply on a running AP ------------------------------------------------
if [ "$1" = "reapply" ]; then
    _CFG=${2:-/tmp/uaputl.cfg}
    [ -s "$_CFG" ] || { echo "reapply: no $_CFG" >> $LOG; exit 1; }
    _WAS=0
    bss_started && _WAS=1
    [ $_WAS = 1 ] && $UAP bss_stop >> $LOG 2>&1
    apply_cfg "$_CFG"
    apply_ie
    [ $_WAS = 1 ] && $UAP bss_start >> $LOG 2>&1
    $UAP sys_cfg_channel >> $LOG 2>&1
#    drop_ipv6_bg
    exit 0
fi

# ---- normal path: same steps and order as the stock script -----------------
# if AP is started, then stop it.
if bss_started; then
    $UAP bss_stop
fi

# set new configuration (HT20 + channel), stock config as fallback.
apply_cfg "$2"
apply_ie

# enable listen before talk (ED-MAC) if needed.
if [[ $1 != "0" ]]; then
    $UAP hostcmd /eso/telephone/ed_mac_ctrl.conf ed_mac_enable
fi

# disable deep sleep mode.
$UAP deepsleep 0

# set coexistence configuration.
$UAP coex_config /eso/telephone/coex.cfg

# aggregation table as on MIB2+ (A-MPDU on TID 0-5, i.e. also WMM video).
$UAP aggrpriotbl 2 255 0 255 1 255 3 255 4 255 5 255 255 255 255 255

# no IPv6 on uap0 (see drop_ipv6_bg): the connection manager brings it up after this
#drop_ipv6_bg
