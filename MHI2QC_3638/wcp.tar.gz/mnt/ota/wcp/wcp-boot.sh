#!/bin/sh
# wcp-boot.sh - wireless CarPlay daemons
#
#   sh /mnt/ota/wcp/wcp-boot.sh start     start (does nothing if wcpd runs already)
#   sh /mnt/ota/wcp/wcp-boot.sh stop      stop wcpd, wcppaird and a wireless dio_manager
#   sh /mnt/ota/wcp/wcp-boot.sh restart
#   sh /mnt/ota/wcp/wcp-boot.sh status
#
# At boot it is started by AltScreen.sh start (in the background) and by the
# btstack wrapper - whichever is first; the second finds wcpd running. dio_manager is NOT started here: wcpd starts it on demand (dio-up.sh)
# when an iPhone is on Bluetooth; smartphone_integrator starts it for USB as
# stock; it ends itself after each session.
#
# Settings (optional): /mnt/ota/app/wcp.conf, sourced as shell, e.g.
#   BTMAC=AA:BB:CC:DD:EE:FF      the car's Bluetooth address - normally NOT needed:
#                                libbthook reads it from the stack (/tmp/wcp_btmac)
#   WCP_KEEP_BT=0                1: the hook answers disableBluetooth (Bluetooth stays)
# Logs: only DEBUG_LOG=1 builds and only while /mnt/ota/app/debug_wificp exists.
W=/mnt/ota/wcp
BTMAC=
# nothing preloaded into the daemons (when called from the btstack wrapper).
# unset, not "LD_PRELOAD=": an empty LD_PRELOAD makes QNX's runtime linker
# fail to start the program at all
unset LD_PRELOAD
[ -f /mnt/ota/app/wcp.conf ] && . /mnt/ota/app/wcp.conf     # all control files: /mnt/ota/app
DBG=/mnt/ota/app/debug_wificp
# function names with a prefix: QNX's ksh has predefined aliases (stop='kill -STOP'
# among them) that are expanded even in "name() {" - a plain stop() is a syntax error
wcp_log() { [ -f $DBG ] && echo "$(date) wcp-boot: $*" >> /tmp/wcp_boot.log; }
wcp_running() { [ -n "$(pidin -p $1 -f a 2>/dev/null | sed -n '1!p')" ]; }

wcp_stop() {
    slay -f wcpd     > /dev/null 2>&1
    slay -f wcppaird > /dev/null 2>&1
    if [ -f /tmp/wcp_dio_mode ]; then
        read M P < /tmp/wcp_dio_mode
        [ "$M" = wireless ] && [ -n "$P" ] && kill $P > /dev/null 2>&1
    fi
    rm -f /tmp/wcp_go /tmp/wcp_dio_ready
    wcp_log "stopped"
}

# one start at a time (AltScreen.sh and the btstack wrapper may both call
# start at boot): exclusive create of a lock file (noclobber; /tmp has no
# directories for a mkdir lock). A lock whose shell is gone is taken over.
LOCK=/tmp/wcp_boot.lock
wcp_lock() {
    if ( set -C; echo $$ > $LOCK ) 2>/dev/null; then return 0; fi
    read LP < $LOCK 2>/dev/null
    if [ -n "$LP" ] && kill -0 "$LP" 2>/dev/null; then return 1; fi
    rm -f $LOCK
    ( set -C; echo $$ > $LOCK ) 2>/dev/null
}

wcp_start() {
    if wcp_running wcpd; then wcp_log "already running"; return 0; fi
    if ! wcp_lock; then wcp_log "another start is running"; return 0; fi
    wcp_start_locked
    rm -f $LOCK
}

wcp_start_locked() {
    cd $W || return 1
    # very early at boot (AltScreen.sh start runs before the services):
    # wait for the MFi chip's i2c bus - wcpd and wcppaird need it at start
    i=0
    while [ ! -e /dev/i2c8 ] && [ $i -lt 90 ]; do sleep 1; i=$((i + 1)); done
    [ $i -gt 0 ] && wcp_log "waited $i s for /dev/i2c8"
    if wcp_running wcpd; then wcp_log "already running (started meanwhile)"; return 0; fi
    sysctl -w kern.sbmax=1048576 > /dev/null 2>&1      # audio relay socket buffers
    [ -n "$BTMAC" ] && echo "$BTMAC" > /tmp/wcp_btmac    # configured: overrides what libbthook finds
    rm -f /tmp/wcp_go /tmp/wcp_cmd /tmp/wcp_dio_ready
    printf 'state=DISCONNECTED\nname=iPhone\nmac=\nip=\nsince=0\n' > /tmp/wcp_session
    # pairing helper (MIB2+ AirPlay 320 pairing code + the car's MFi chip)
    LD_LIBRARY_PATH=$W/nv:$W:$LD_LIBRARY_PATH ./wcppaird > /dev/null 2>&1 &
    # Bluetooth iAP2 (Wi-Fi handover); dio_manager on demand; StartSession once
    # the HMI has started the receiver (/tmp/wcp_go)
    LD_LIBRARY_PATH=$W:$LD_LIBRARY_PATH WCP_START=1 WCP_BTMAC=$BTMAC WCP_GATE=/tmp/wcp_go \
        WCP_DIO_UP=$W/dio-up.sh ./wcpd > /dev/null 2>&1 &
    sleep 1
    for p in wcppaird wcpd; do
        wcp_running $p || echo "wcp-boot: $p did not start - run it by hand in $W to see why"
    done
    wcp_log "started (BTMAC $BTMAC)"
    wcp_btmac_save > /dev/null 2>&1 &
}

# The car's Bluetooth address goes into the Apple element of the access point
# (start-ap.sh). libbthook finds it ~10 s after boot, after the first AP start,
# so it is kept in /mnt/ota/wcp/btmac.last for the next boot. When it is new or
# changed (first boot, another car), the element is installed again now - only
# through our start-ap.sh (the stock script would stop the access point).
wcp_btmac_save() {
    AP=/eso/telephone/start-ap.sh
    i=0
    while [ ! -s /tmp/wcp_btmac ] && [ $i -lt 120 ]; do sleep 2; i=$((i + 2)); done
    [ -s /tmp/wcp_btmac ] || { wcp_log "car Bluetooth address not found - Apple element unchanged"; return 0; }
    NEW=$(cat /tmp/wcp_btmac)
    OLD=$(cat $W/btmac.last 2>/dev/null)
    [ "$NEW" = "$OLD" ] && return 0
    echo "$NEW" > $W/btmac.last && wcp_log "car Bluetooth address $NEW saved (was '${OLD:-none}')"
    if grep -q "RGI-Q overlay" $AP 2>/dev/null; then
        $AP ie && wcp_log "Apple element installed again"
    fi
}

case "$1" in
    start)   wcp_start ;;
    stop)    wcp_stop ;;
    restart) wcp_stop; sleep 1; wcp_start ;;
    status)
        for p in wcpd wcppaird dio_manager dio_manager.orig; do
            if wcp_running $p; then echo "$p: running"; else echo "$p: -"; fi
        done
        echo "dio_manager mode: $(cat /tmp/wcp_dio_mode 2>/dev/null || echo -)"
        echo "session: $(sed -n 's/^state=//p' /tmp/wcp_session 2>/dev/null)"
        [ -f $DBG ] && echo "logging: on ($DBG)" || echo "logging: off (touch $DBG, DEBUG_LOG=1 builds)"
        [ -f ${DBG}_raw ] && echo "raw dumps: on (${DBG}_raw - large logs)" || echo "raw dumps: off (touch ${DBG}_raw for hex dumps)" ;;
    *) echo "usage: $0 start|stop|restart|status"; exit 1 ;;
esac
