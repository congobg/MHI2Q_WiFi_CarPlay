#!/bin/ksh
# aaw-boot.sh - start / stop aawd for wireless Android Auto (QC_WiFi_AAuto).
#   ksh aaw-boot.sh start | stop | status
# aawd -w: libbthook's Android Auto Bluetooth bridge on 127.0.0.1:57344, phones on TCP 5288
# (uap0, 10.173.189.1). aawd is taken from $AAW_DIR (default /mnt/ota/wcp, next to wcpd).
# Off: aaw_off in /mnt/ota/app or /mnt/ota/wcp (libbthook reads it in /tmp or /mnt/ota/wcp).
# QNX ksh (pdksh): no case inside $( ), LF line endings.
W=${AAW_DIR:-/mnt/ota/wcp}

aaw_running() { [ -n "$(pidin -p aawd -f a 2>/dev/null | sed -n '1!p')" ]; }

case "$1" in
start)
    if [ -f /mnt/ota/app/aaw_off ] || [ -f /mnt/ota/wcp/aaw_off ]; then
        echo "aaw_off present - aawd not started"
        exit 0
    fi
    if aaw_running; then
        echo "aawd already running"
        exit 0
    fi
    if [ ! -x $W/aawd ]; then
        echo "no $W/aawd"
        exit 1
    fi
    cd $W && ./aawd -w > /dev/null 2>&1 &
    echo "aawd started"
    ;;
stop)
    slay -f aawd > /dev/null 2>&1
    rm -f /tmp/aaw_vdev
    echo "aawd stopped"
    ;;
status)
    if aaw_running; then echo "aawd running"; else echo "aawd not running"; fi
    ;;
*)
    echo "usage: ksh $0 start | stop | status"
    exit 1
    ;;
esac
