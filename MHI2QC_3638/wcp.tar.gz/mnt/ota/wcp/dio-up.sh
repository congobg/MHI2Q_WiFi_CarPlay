#!/bin/sh
# dio-up.sh - start the stock dio_manager in wireless mode, unless one runs already.
#
# Called by wcpd (WCP_DIO_UP) when an iPhone's Bluetooth iAP2 link comes up: the
# part smartphone_integrator plays for a USB phone. Nothing is started while any
# dio_manager runs - a USB CarPlay session keeps its dio_manager. It goes through
# the dio_manager wrapper (same preloads as for USB); WCP_DIO_WIRELESS=1 makes
# libwcpstart active and the wrapper record "wireless <pid>" in /tmp/wcp_dio_mode.
# dio_manager ends itself after the session; the next phone starts it again.
#
# Log (only while /mnt/ota/app/debug_wificp exists): /tmp/wcp_dio_up.log,
# dio_manager's own output in /tmp/dio_manual.log.
DIO_LIBS=/mnt/app/root/lib-target:/eso/lib:/mnt/app/usr/lib:/mnt/app/armle/lib:/mnt/app/armle/lib/dll:/mnt/app/armle/usr/lib
DBG=/mnt/ota/app/debug_wificp
dio_log() { [ -f $DBG ] && echo "$(date) dio-up: $*" >> /tmp/wcp_dio_up.log; }
OUT=/dev/null; [ -f $DBG ] && OUT=/tmp/dio_manual.log
[ -f /mnt/ota/app/wcp.conf ] && . /mnt/ota/app/wcp.conf

# crash watch (AltScreen.sh): a wireless dio_manager that crashed twice within 10 min
# is not started again until the next reboot; USB CarPlay is not affected
if [ -f /tmp/wcp_dio_off ]; then
    dio_log "wireless dio_manager off until reboot: `cat /tmp/wcp_dio_off`"
    exit 0
fi

# stock/dio_manager (AltScreen.sh) runs as "dio_manager", older layouts as "dio_manager.orig"
if [ -n "$(pidin -p dio_manager -f a 2>/dev/null | sed -n '1!p')$(pidin -p dio_manager.orig -f a 2>/dev/null | sed -n '1!p')" ]; then
    dio_log "dio_manager already running ($(cat /tmp/wcp_dio_mode 2>/dev/null)) - nothing started"
    exit 0
fi
# WCP_DIO_CONFIG_DIR (wcp.conf): a folder with its own dio_manager.json for the
# wireless dio_manager, e.g. with the Cinemo log in a file at trace level
dio_log "starting dio_manager (wireless)${WCP_DIO_CONFIG_DIR:+, config from $WCP_DIO_CONFIG_DIR}"
rm -f /tmp/wcp_dio_ready /tmp/wcp_go     # nothing runs: anything left over is stale
# Bonjour: dio_manager starts mdnsd in initService(), which smartphone_integrator
# calls for a USB phone. 5092's SI does not call it for a wireless dio_manager
# (car test 27 Oct: no mdnsd, DNSServiceRegister -65563, the phone stopped after
# pair-verify) - start it here the way dio_manager does (dio_manager.json "mdnsd").
# A later initService() stops it through the pid file and starts its own.
MDNSD=/mnt/app/armle/usr/sbin/mdnsd
if [ "${WCP_MDNSD:-1}" != 0 ] && [ -x $MDNSD ] && [ -z "$(pidin -p mdnsd -f a 2>/dev/null | sed -n '1!p')" ]; then
    if [ -f /etc/scripts/mdnsd.sh ]; then sh /etc/scripts/mdnsd.sh > /dev/null 2>&1; else mkdir -p /var/run/mdnsd; fi
    MDNS_DIRECTLINK_IFACE=${WCP_IFACE:-uap0} mDNSPlatformDefaultProbeCountForTypeUnique=0 $MDNSD > /dev/null 2>&1 &
    echo $! > /var/run/mdnsd/mdnsd.pid
    dio_log "mdnsd was not running - started (pid $!, Bonjour for the wireless receiver)"
fi
cd /mnt/app/eso/bin/apps || exit 1
WCP_DIO_WIRELESS=1 WCP_IAP_AIRPLAY=1 WCP_KEEP_BT=${WCP_KEEP_BT:-0} WCP_DIO_TRACE=${WCP_DIO_TRACE:-} \
    WCP_BTMAC=$(cat /tmp/wcp_btmac 2>/dev/null) LD_LIBRARY_PATH=$DIO_LIBS \
    IPL_CONFIG_DIR_DIO_MANAGER=${WCP_DIO_CONFIG_DIR:-/etc/eso/production} ./dio_manager >> $OUT 2>&1 &
