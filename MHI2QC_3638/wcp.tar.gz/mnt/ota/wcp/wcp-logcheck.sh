#!/bin/sh
# wcp-logcheck.sh - the lines that matter from the wireless CarPlay logs
#
#   sh /mnt/ota/wcp/wcp-logcheck.sh          current run (/tmp/*.log)
#   sh /mnt/ota/wcp/wcp-logcheck.sh prev     the run before the last wcp-test4.sh restart
#   sh /mnt/ota/wcp/wcp-logcheck.sh prev > /mnt/ota/wcp/check.txt     to send
#
# NUL bytes are removed first (the log can contain some, and grep then calls
# it a binary file).
P=/tmp/
[ "$1" = prev ] && P=/tmp/prev_
H=/tmp/wcp_check_hook.txt
D=/tmp/wcp_check_wcpd.txt
tr -d '\000' < ${P}wcphook.log > $H 2>/dev/null
tr -d '\000' < ${P}wcpd.log    > $D 2>/dev/null

echo "===== sessions (hook)"
grep -E "=== fd [0-9]+: Wi-Fi connection|control channel encrypted|session status|session over|control closed|event closed" $H | tail -30

echo; echo "===== alarms (*** lines)"
grep -E "\*\*\*" $H | grep -vE "disableBluetooth|AirPlayReceiverServerControl|CFRunLoopStop|AirPlayReceiverSessionTearDown|control channel encrypted" | tail -15

echo; echo "===== event channel"
echo "pump started:            $(grep -c 'event pump: reading' $H)"
echo "requests piling up:      $(grep -c 'requests waiting for a reply' $H)   (0 expected)"
echo "queue full:              $(grep -c 'queue FULL' $H)   (0 expected)"
echo "reply with no request:   $(grep -c 'no request waiting' $H)   (0 expected)"
echo "late replies (>1 s):     $(grep -c 'event channel: reply to' $H)"
echo "stock requests (touch):  $(grep -c 'stock request #' $H)"
grep -E "event pump|has had no reply|queue FULL|no request waiting|stock request #|event closed" $H | tail -12

echo; echo "===== who ended the session"
# TearDown called from libairplay+0x2fda4 ends single streams (music paused, a
# prompt over, screen off) - normal; the session itself ends elsewhere
grep -E "phone silent|left the Wi-Fi|AirPlayReceiverSessionTearDown|session over|decrypt failed|bad frame|buffer full" $H | grep -v "libairplay.so+0x2fda4" | tail -10
echo "stream teardowns (streams ending - normal): $(grep -c 'libairplay.so+0x2fda4' $H)"

echo; echo "===== phone watchdog (silent phone: what arrived when, what was waiting)"
grep -E "phone watchdog|last bytes .* ms ago|is back after|still on the Wi-Fi|receiver is behind" $H | tail -24

echo; echo "===== stock idle timer (keep-alive beacons as session activity)"
grep -E "stock idle timer|count as session activity|sessionDied" $H | tail -6
grep -E "AP snapshot" $D | tail -16

echo; echo "===== iAP2 inside the session"
grep -E "iAP2 over AirPlay: |iAPSendMessage [0-9]+ sent|not accepted by the phone|iAP2 client|iAP2Connect" $H | tail -14
[ -f /tmp/wcpstart.log ] && grep -E "iAP2Connect|iAP2 direct connect" /tmp/wcpstart.log | tail -4

echo; echo "===== Bonjour (mdnsd, the receiver's record)"
[ -f /tmp/wcpstart.log ] && grep -E "Bonjour: |model=" /tmp/wcpstart.log | tail -4
grep -E "mdnsd" /tmp/wcp_dio_up.log 2>/dev/null | tail -3
n=$(pidin -p mdnsd -f a 2>/dev/null | sed -n '1!p' | wc -l); echo "mdnsd processes running: $((n))"   # no tr: it crashes on these units

echo; echo "===== audio relay (end of each stream)"
grep -E "relay: stream [0-9]+ closed" $H | tail -10

echo; echo "===== wcpd: on-demand start, offer, recovery"
grep -E "phone link (up|down)|starting dio_manager|is up after|offering|AVAILABLE|StartSession|no CarPlay session|stale|stopping the wireless|still waiting|USB CarPlay|pairing identifier|AP: station" $D | tail -25

echo; echo "===== Bluetooth (libbthook): car-initiated iAP2, USB sessions"
tr -d '\000' < ${P}bthook.log 2>/dev/null | grep -E "USB CarPlay|opening iAP2|iAP2 channel (open|closed)|Bluetooth address" | tail -8

echo; echo "===== dio_manager starts"
tr -d '\000' < ${P}wcp_dio_up.log 2>/dev/null | tail -8

rm -f $H $D
