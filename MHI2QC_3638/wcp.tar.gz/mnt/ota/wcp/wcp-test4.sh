#!/bin/sh
# wcp-test4.sh - manual start for tests: the same as at boot (wcp-boot.sh), with
# the previous logs kept as /tmp/prev_*.
#
#   sh /mnt/ota/wcp/wcp-test4.sh          restart the daemons
#   sh /mnt/ota/wcp/wcp-test4.sh stop     stop them (and a wireless dio_manager)
#
# dio_manager is started on demand by wcpd when the iPhone is on Bluetooth
# (dio-up.sh) and by smartphone_integrator for USB; it ends after each session.
# Logs: touch /mnt/ota/app/debug_wificp (DEBUG_LOG=1 builds).
W=/mnt/ota/wcp
sh $W/wcp-boot.sh stop
[ "$1" = "stop" ] && { echo "stopped"; exit 0; }
# the previous run's logs are kept as /tmp/prev_<name> (overwritten at the next
# restart) - a drop can still be looked at after restarting. No directory:
# /tmp is /dev/shmem on this unit, which has none.
for f in wcphook.log wcpstart.log wcpd.log wcppaird.log bthook.log dio_trace.log dio_manual.log \
         wcp_dio_up.log wcp_boot.log wcp_hmi.log; do
    [ -f /tmp/$f ] && mv -f /tmp/$f /tmp/prev_$f
done
sloginfo > /tmp/prev_slog.txt 2>/dev/null
sleep 1
sh $W/wcp-boot.sh start
sh $W/wcp-boot.sh status
echo "logs (with /mnt/ota/app/debug_wificp):"
echo "  /tmp/wcpd.log      Bluetooth iAP2, Wi-Fi setup, dio_manager on demand"
echo "  /tmp/wcphook.log   CarPlay session, iAP2 inside it, audio"
echo "  /tmp/bthook.log    Bluetooth stack (iAP2 channel, advertisement)"
echo "  /tmp/wcp_dio_up.log, /tmp/wcp_hmi.log"
echo "  previous run: /tmp/prev_*.log, /tmp/prev_slog.txt (sloginfo at the restart)"
